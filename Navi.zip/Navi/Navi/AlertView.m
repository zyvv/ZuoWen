//
//  AlertView.m
//  Navi
//
//  Created by 张洋威 on 2017/4/9.
//  Copyright © 2017年 张洋威. All rights reserved.
//

#import "AlertView.h"
#import <Masonry.h>
#import "AViewController.h"
#import "BViewController.h"
#import "CViewController.h"

@implementation AlertView
{
    UINavigationController *nav;
}

- (instancetype)init {
    self = [super init];
    if (self) {
        [self mas_makeConstraints:^(MASConstraintMaker *make) {
            make.size.mas_equalTo(CGSizeMake(300, 200));
        }];
        self.backgroundColor = [UIColor whiteColor];

        AViewController *av = [AViewController new];
        nav = [[UINavigationController alloc] initWithRootViewController:av];
        nav.navigationBar.hidden = YES;
        [self addSubview:nav.view];
        [nav.view mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.equalTo(self);
        }];
    }
    return self;
}



@end
