//
//  BViewController.m
//  Navi
//
//  Created by 张洋威 on 2017/4/9.
//  Copyright © 2017年 张洋威. All rights reserved.
//

#import "BViewController.h"
#import <Masonry.h>
#import "CViewController.h"

@interface BViewController ()

@end

@implementation BViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = [UIColor orangeColor];
//    self.view.frame = CGRectMake(0, 0, 30, 30);
//    [se]
    
    UIView *view = [UIView new];
    view.backgroundColor = [UIColor blueColor];
    [self.view addSubview:view];
    [view mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.left.equalTo(self.view);
        make.right.equalTo(self.view).offset(-40);
        make.bottom.equalTo(self.view).offset(-30);
    }];
    
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    button.backgroundColor = [UIColor cyanColor];
    [button setTitle:@"2" forState:UIControlStateNormal];
    [self.view addSubview:button];
    [button mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.view).offset(15);
        make.size.mas_equalTo(CGSizeMake(30, 30));
        make.left.equalTo(self.view).offset(25);
    }];
    [button addTarget:self action:@selector(bb) forControlEvents:UIControlEventTouchUpInside];
}

- (void)bb {
    CViewController *cv = [CViewController new];
    [self.navigationController pushViewController:cv animated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
